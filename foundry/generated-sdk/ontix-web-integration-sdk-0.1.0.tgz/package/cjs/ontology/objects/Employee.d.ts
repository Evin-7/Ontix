import type { PropertyDef as $PropertyDef } from '@osdk/client';
import { $osdkMetadata } from '../../OntologyMetadata.js';
import type { Team } from './Team.js';
import type { OperationalCase } from './OperationalCase.js';
import type { ObjectTypeDefinition as $ObjectTypeDefinition, ObjectMetadata as $ObjectMetadata } from '@osdk/client';
import type { ObjectSet as $ObjectSet, Osdk as $Osdk, PropertyValueWireToClient as $PropType, SingleLinkAccessor as $SingleLinkAccessor } from '@osdk/client';
export declare namespace Employee {
    type PropertyKeys = 'email' | 'id' | 'name' | 'role' | 'teamId';
    interface Links {
        readonly assignedCases: OperationalCase.ObjectSet;
        readonly team: $SingleLinkAccessor<Team>;
    }
    interface Props {
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Email'
         */
        readonly email: $PropType['string'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Id'
         */
        readonly id: $PropType['string'];
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Name'
         */
        readonly name: $PropType['string'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Role'
         */
        readonly role: $PropType['string'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Team Id'
         */
        readonly teamId: $PropType['string'] | undefined;
    }
    type StrictProps = Props;
    interface ObjectSet extends $ObjectSet<Employee, Employee.ObjectSet> {
    }
    type OsdkInstance<OPTIONS extends never | '$rid' = never, K extends keyof Employee.Props = keyof Employee.Props> = $Osdk.Instance<Employee, OPTIONS, K>;
    /** @deprecated use OsdkInstance */
    type OsdkObject<OPTIONS extends never | '$rid' = never, K extends keyof Employee.Props = keyof Employee.Props> = OsdkInstance<OPTIONS, K>;
}
export interface Employee extends $ObjectTypeDefinition {
    osdkMetadata: typeof $osdkMetadata;
    type: 'object';
    apiName: 'Employee';
    primaryKeyApiName: 'id';
    primaryKeyType: 'string';
    __DefinitionMetadata?: {
        objectSet: Employee.ObjectSet;
        props: Employee.Props;
        linksType: Employee.Links;
        strictProps: Employee.StrictProps;
        apiName: 'Employee';
        description: 'Team members who can own operational work.';
        displayName: 'Employee';
        icon: {
            type: 'blueprint';
            color: '#4C90F0';
            name: 'cube';
        };
        implements: [];
        interfaceMap: {};
        inverseInterfaceMap: {};
        links: {
            assignedCases: $ObjectMetadata.Link<OperationalCase, true>;
            team: $ObjectMetadata.Link<Team, false>;
        };
        pluralDisplayName: 'Employees';
        primaryKeyApiName: 'id';
        primaryKeyType: 'string';
        properties: {
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Email'
             */
            email: $PropertyDef<'string', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Id'
             */
            id: $PropertyDef<'string', 'non-nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Name'
             */
            name: $PropertyDef<'string', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Role'
             */
            role: $PropertyDef<'string', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Team Id'
             */
            teamId: $PropertyDef<'string', 'nullable', 'single'>;
        };
        rid: 'ri.ontology.main.object-type.164cb890-15f1-450b-982b-ecdb7800631b';
        status: 'EXPERIMENTAL';
        titleProperty: 'name';
        type: 'object';
        visibility: 'NORMAL';
    };
}
export declare const Employee: Employee;
