import type { PropertyDef as $PropertyDef } from '@osdk/client';
import { $osdkMetadata } from '../../OntologyMetadata.js';
import type { Project } from './Project.js';
import type { Employee } from './Employee.js';
import type { ApprovalRequest } from './ApprovalRequest.js';
import type { ObjectTypeDefinition as $ObjectTypeDefinition, ObjectMetadata as $ObjectMetadata } from '@osdk/client';
import type { ObjectSet as $ObjectSet, Osdk as $Osdk, PropertyValueWireToClient as $PropType, SingleLinkAccessor as $SingleLinkAccessor } from '@osdk/client';
export declare namespace OperationalCase {
    type PropertyKeys = 'assignedEmployeeId' | 'id' | 'priority' | 'projectId' | 'status' | 'title';
    interface Links {
        readonly approvalRequests: ApprovalRequest.ObjectSet;
        readonly assignedEmployee: $SingleLinkAccessor<Employee>;
        readonly project: $SingleLinkAccessor<Project>;
    }
    interface Props {
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Assigned Employee Id'
         */
        readonly assignedEmployeeId: $PropType['string'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Id'
         */
        readonly id: $PropType['string'];
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Priority'
         */
        readonly priority: $PropType['string'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Project Id'
         */
        readonly projectId: $PropType['string'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Status'
         */
        readonly status: $PropType['string'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Title'
         */
        readonly title: $PropType['string'] | undefined;
    }
    type StrictProps = Props;
    interface ObjectSet extends $ObjectSet<OperationalCase, OperationalCase.ObjectSet> {
    }
    type OsdkInstance<OPTIONS extends never | '$rid' = never, K extends keyof OperationalCase.Props = keyof OperationalCase.Props> = $Osdk.Instance<OperationalCase, OPTIONS, K>;
    /** @deprecated use OsdkInstance */
    type OsdkObject<OPTIONS extends never | '$rid' = never, K extends keyof OperationalCase.Props = keyof OperationalCase.Props> = OsdkInstance<OPTIONS, K>;
}
export interface OperationalCase extends $ObjectTypeDefinition {
    osdkMetadata: typeof $osdkMetadata;
    type: 'object';
    apiName: 'OperationalCase';
    primaryKeyApiName: 'id';
    primaryKeyType: 'string';
    __DefinitionMetadata?: {
        objectSet: OperationalCase.ObjectSet;
        props: OperationalCase.Props;
        linksType: OperationalCase.Links;
        strictProps: OperationalCase.StrictProps;
        apiName: 'OperationalCase';
        description: 'Operational cases linked to customer projects and assigned employees.';
        displayName: 'OperationalCase';
        icon: {
            type: 'blueprint';
            color: '#4C90F0';
            name: 'cube';
        };
        implements: [];
        interfaceMap: {};
        inverseInterfaceMap: {};
        links: {
            approvalRequests: $ObjectMetadata.Link<ApprovalRequest, true>;
            assignedEmployee: $ObjectMetadata.Link<Employee, false>;
            project: $ObjectMetadata.Link<Project, false>;
        };
        pluralDisplayName: 'OperationalCases';
        primaryKeyApiName: 'id';
        primaryKeyType: 'string';
        properties: {
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Assigned Employee Id'
             */
            assignedEmployeeId: $PropertyDef<'string', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Id'
             */
            id: $PropertyDef<'string', 'non-nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Priority'
             */
            priority: $PropertyDef<'string', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Project Id'
             */
            projectId: $PropertyDef<'string', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Status'
             */
            status: $PropertyDef<'string', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Title'
             */
            title: $PropertyDef<'string', 'nullable', 'single'>;
        };
        rid: 'ri.ontology.main.object-type.4cbfd8ef-0dbf-4e2e-8f96-53be0d94a43d';
        status: 'EXPERIMENTAL';
        titleProperty: 'title';
        type: 'object';
        visibility: 'NORMAL';
    };
}
export declare const OperationalCase: OperationalCase;
