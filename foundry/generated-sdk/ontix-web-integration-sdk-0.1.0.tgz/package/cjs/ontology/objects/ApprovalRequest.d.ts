import type { PropertyDef as $PropertyDef } from '@osdk/client';
import { $osdkMetadata } from '../../OntologyMetadata.js';
import type { OperationalCase } from './OperationalCase.js';
import type { ObjectTypeDefinition as $ObjectTypeDefinition, ObjectMetadata as $ObjectMetadata } from '@osdk/client';
import type { ObjectSet as $ObjectSet, Osdk as $Osdk, PropertyValueWireToClient as $PropType, SingleLinkAccessor as $SingleLinkAccessor } from '@osdk/client';
export declare namespace ApprovalRequest {
    type PropertyKeys = 'caseId' | 'createdAt' | 'id' | 'requestedBy' | 'status';
    interface Links {
        readonly operationalCase: $SingleLinkAccessor<OperationalCase>;
    }
    interface Props {
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Case Id'
         */
        readonly caseId: $PropType['string'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Created At'
         */
        readonly createdAt: {
            offset: $PropType['integer'] | undefined;
            timestamp: $PropType['timestamp'] | undefined;
        } | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Id'
         */
        readonly id: $PropType['string'];
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Requested By'
         */
        readonly requestedBy: $PropType['string'] | undefined;
        /**
         * @experimental
         *
         *   property status: experimental
         *
         *   display name: 'Status'
         */
        readonly status: $PropType['string'] | undefined;
    }
    type StrictProps = Props;
    interface ObjectSet extends $ObjectSet<ApprovalRequest, ApprovalRequest.ObjectSet> {
    }
    type OsdkInstance<OPTIONS extends never | '$rid' = never, K extends keyof ApprovalRequest.Props = keyof ApprovalRequest.Props> = $Osdk.Instance<ApprovalRequest, OPTIONS, K>;
    /** @deprecated use OsdkInstance */
    type OsdkObject<OPTIONS extends never | '$rid' = never, K extends keyof ApprovalRequest.Props = keyof ApprovalRequest.Props> = OsdkInstance<OPTIONS, K>;
}
export interface ApprovalRequest extends $ObjectTypeDefinition {
    osdkMetadata: typeof $osdkMetadata;
    type: 'object';
    apiName: 'ApprovalRequest';
    primaryKeyApiName: 'id';
    primaryKeyType: 'string';
    __DefinitionMetadata?: {
        objectSet: ApprovalRequest.ObjectSet;
        props: ApprovalRequest.Props;
        linksType: ApprovalRequest.Links;
        strictProps: ApprovalRequest.StrictProps;
        apiName: 'ApprovalRequest';
        description: 'Approval requests associated with operational cases.';
        displayName: 'ApprovalRequest';
        icon: {
            type: 'blueprint';
            color: '#4C90F0';
            name: 'cube';
        };
        implements: [];
        interfaceMap: {};
        inverseInterfaceMap: {};
        links: {
            operationalCase: $ObjectMetadata.Link<OperationalCase, false>;
        };
        pluralDisplayName: 'ApprovalRequests';
        primaryKeyApiName: 'id';
        primaryKeyType: 'string';
        properties: {
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Case Id'
             */
            caseId: $PropertyDef<'string', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Created At'
             */
            createdAt: $PropertyDef<{
                timestamp: 'timestamp';
                offset: 'integer';
            }, 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Id'
             */
            id: $PropertyDef<'string', 'non-nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Requested By'
             */
            requestedBy: $PropertyDef<'string', 'nullable', 'single'>;
            /**
             * @experimental
             *
             *   property status: experimental
             *
             *   display name: 'Status'
             */
            status: $PropertyDef<'string', 'nullable', 'single'>;
        };
        rid: 'ri.ontology.main.object-type.29983db4-c57f-464d-be76-525e1817c2d4';
        status: 'EXPERIMENTAL';
        titleProperty: 'caseId';
        type: 'object';
        visibility: 'NORMAL';
    };
}
export declare const ApprovalRequest: ApprovalRequest;
