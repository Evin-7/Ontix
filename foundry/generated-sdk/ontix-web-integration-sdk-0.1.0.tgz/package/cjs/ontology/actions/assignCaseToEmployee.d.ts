import type { ActionDefinition, ActionMetadata, ActionParam, ActionReturnTypeForOptions, ApplyActionOptions, ApplyBatchActionOptions } from '@osdk/client';
import { $osdkMetadata } from '../../OntologyMetadata.js';
import type { OperationalCase } from '../objects/OperationalCase.js';
import type { Employee } from '../objects/Employee.js';
export declare namespace assignCaseToEmployee {
    type ParamsDefinition = {
        employee: {
            description: 'Select the Employee to assign to this case.';
            displayName: 'New parameter';
            multiplicity: false;
            nullable: false;
            type: ActionMetadata.DataType.Object<Employee>;
        };
        operationalCase: {
            description: undefined;
            displayName: 'OperationalCase';
            multiplicity: false;
            nullable: false;
            type: ActionMetadata.DataType.Object<OperationalCase>;
        };
    };
    /**
     * Assign an existing Employee to a case. Assignment is allowed while the case is OPEN, IN_PROGRESS, or WAITING_APPROVAL.
     */
    interface Params {
        /**
         * Select the Employee to assign to this case.
         */
        readonly employee: ActionParam.ObjectType<Employee>;
        readonly operationalCase: ActionParam.ObjectType<OperationalCase>;
    }
    interface Signatures {
        /**
         * Assign an existing Employee to a case. Assignment is allowed while the case is OPEN, IN_PROGRESS, or WAITING_APPROVAL.
         */
        applyAction<OP extends ApplyActionOptions>(args: assignCaseToEmployee.Params, options?: OP): Promise<ActionReturnTypeForOptions<OP>>;
        batchApplyAction<OP extends ApplyBatchActionOptions>(args: ReadonlyArray<assignCaseToEmployee.Params>, options?: OP): Promise<ActionReturnTypeForOptions<OP>>;
    }
}
/**
 * Assign an existing Employee to a case. Assignment is allowed while the case is OPEN, IN_PROGRESS, or WAITING_APPROVAL.
 * @param {ActionParam.ObjectType<Employee>} employee Select the Employee to assign to this case.
 * @param {ActionParam.ObjectType<OperationalCase>} operationalCase
 */
export interface assignCaseToEmployee extends ActionDefinition<assignCaseToEmployee.Signatures> {
    __DefinitionMetadata?: {
        apiName: 'assignCaseToEmployee';
        description: 'Assign an existing Employee to a case. Assignment is allowed while the case is OPEN, IN_PROGRESS, or WAITING_APPROVAL.';
        displayName: 'AssignCaseToEmployee';
        modifiedEntities: {
            OperationalCase: {
                created: false;
                modified: true;
            };
        };
        parameters: assignCaseToEmployee.ParamsDefinition;
        rid: 'ri.actions.main.action-type.c5aa3f3d-5d96-432e-964b-257957fdb2b8';
        status: 'EXPERIMENTAL';
        type: 'action';
        unsanitizedApiName: 'assign-case-to-employee';
        signatures: assignCaseToEmployee.Signatures;
    };
    apiName: 'assignCaseToEmployee';
    type: 'action';
    unsanitizedApiName: 'assign-case-to-employee';
    osdkMetadata: typeof $osdkMetadata;
}
export declare const assignCaseToEmployee: assignCaseToEmployee;
