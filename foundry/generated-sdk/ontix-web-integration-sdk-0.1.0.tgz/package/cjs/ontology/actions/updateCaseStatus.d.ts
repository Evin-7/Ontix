import type { ActionDefinition, ActionMetadata, ActionParam, ActionReturnTypeForOptions, ApplyActionOptions, ApplyBatchActionOptions } from '@osdk/client';
import { $osdkMetadata } from '../../OntologyMetadata.js';
import type { OperationalCase } from '../objects/OperationalCase.js';
export declare namespace updateCaseStatus {
    type ParamsDefinition = {
        operationalCase: {
            description: undefined;
            displayName: 'OperationalCase';
            multiplicity: false;
            nullable: false;
            type: ActionMetadata.DataType.Object<OperationalCase>;
        };
        status: {
            description: undefined;
            displayName: 'Status';
            multiplicity: false;
            nullable: false;
            type: 'string';
        };
    };
    /**
     * Resolve cases from OPEN or IN_PROGRESS to RESOLVED. Approval-related transitions are handled by approval actions.
     */
    interface Params {
        readonly operationalCase: ActionParam.ObjectType<OperationalCase>;
        readonly status: ActionParam.PrimitiveType<'string'>;
    }
    interface Signatures {
        /**
         * Resolve cases from OPEN or IN_PROGRESS to RESOLVED. Approval-related transitions are handled by approval actions.
         */
        applyAction<OP extends ApplyActionOptions>(args: updateCaseStatus.Params, options?: OP): Promise<ActionReturnTypeForOptions<OP>>;
        batchApplyAction<OP extends ApplyBatchActionOptions>(args: ReadonlyArray<updateCaseStatus.Params>, options?: OP): Promise<ActionReturnTypeForOptions<OP>>;
    }
}
/**
 * Resolve cases from OPEN or IN_PROGRESS to RESOLVED. Approval-related transitions are handled by approval actions.
 * @param {ActionParam.ObjectType<OperationalCase>} operationalCase
 * @param {ActionParam.PrimitiveType<"string">} status
 */
export interface updateCaseStatus extends ActionDefinition<updateCaseStatus.Signatures> {
    __DefinitionMetadata?: {
        apiName: 'updateCaseStatus';
        description: 'Resolve cases from OPEN or IN_PROGRESS to RESOLVED. Approval-related transitions are handled by approval actions.';
        displayName: 'UpdateCaseStatus';
        modifiedEntities: {
            OperationalCase: {
                created: false;
                modified: true;
            };
        };
        parameters: updateCaseStatus.ParamsDefinition;
        rid: 'ri.actions.main.action-type.d2595684-6178-4556-89c5-3d80f821a547';
        status: 'EXPERIMENTAL';
        type: 'action';
        unsanitizedApiName: 'update-case-status';
        signatures: updateCaseStatus.Signatures;
    };
    apiName: 'updateCaseStatus';
    type: 'action';
    unsanitizedApiName: 'update-case-status';
    osdkMetadata: typeof $osdkMetadata;
}
export declare const updateCaseStatus: updateCaseStatus;
