import type { ActionDefinition, ActionMetadata, ActionParam, ActionReturnTypeForOptions, ApplyActionOptions, ApplyBatchActionOptions } from '@osdk/client';
import { $osdkMetadata } from '../../OntologyMetadata.js';
import type { Project } from '../objects/Project.js';
export declare namespace updateProjectStatus {
    type ParamsDefinition = {
        project: {
            description: undefined;
            displayName: 'Project';
            multiplicity: false;
            nullable: false;
            type: ActionMetadata.DataType.Object<Project>;
        };
        status: {
            description: undefined;
            displayName: 'Status';
            multiplicity: false;
            nullable: false;
            type: 'string';
        };
    };
    /**
     * Update a project's status using the demo status values: PLANNING, IN_PROGRESS, AT_RISK, or COMPLETED.
     */
    interface Params {
        readonly project: ActionParam.ObjectType<Project>;
        readonly status: ActionParam.PrimitiveType<'string'>;
    }
    interface Signatures {
        /**
         * Update a project's status using the demo status values: PLANNING, IN_PROGRESS, AT_RISK, or COMPLETED.
         */
        applyAction<OP extends ApplyActionOptions>(args: updateProjectStatus.Params, options?: OP): Promise<ActionReturnTypeForOptions<OP>>;
        batchApplyAction<OP extends ApplyBatchActionOptions>(args: ReadonlyArray<updateProjectStatus.Params>, options?: OP): Promise<ActionReturnTypeForOptions<OP>>;
    }
}
/**
 * Update a project's status using the demo status values: PLANNING, IN_PROGRESS, AT_RISK, or COMPLETED.
 * @param {ActionParam.ObjectType<Project>} project
 * @param {ActionParam.PrimitiveType<"string">} status
 */
export interface updateProjectStatus extends ActionDefinition<updateProjectStatus.Signatures> {
    __DefinitionMetadata?: {
        apiName: 'updateProjectStatus';
        description: "Update a project's status using the demo status values: PLANNING, IN_PROGRESS, AT_RISK, or COMPLETED.";
        displayName: 'UpdateProjectStatus';
        modifiedEntities: {
            Project: {
                created: false;
                modified: true;
            };
        };
        parameters: updateProjectStatus.ParamsDefinition;
        rid: 'ri.actions.main.action-type.820e0507-06ca-4f8c-ad25-7f6a80781bf6';
        status: 'EXPERIMENTAL';
        type: 'action';
        unsanitizedApiName: 'update-project-status';
        signatures: updateProjectStatus.Signatures;
    };
    apiName: 'updateProjectStatus';
    type: 'action';
    unsanitizedApiName: 'update-project-status';
    osdkMetadata: typeof $osdkMetadata;
}
export declare const updateProjectStatus: updateProjectStatus;
