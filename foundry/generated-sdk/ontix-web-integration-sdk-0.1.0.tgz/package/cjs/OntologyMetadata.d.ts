export type $ExpectedClientVersion = '2.80.0';
export declare const $osdkMetadata: {
    extraUserAgent: string;
};
export declare const $ontologyRid = "ri.ontology.main.ontology.27b95058-04ae-4e08-9161-1058cb0b16f6";
/**
 * The RID of the Foundry branch this SDK was generated against, or
 * `undefined` if it was generated against the main branch.
 */
export declare const $branch: string | undefined;
